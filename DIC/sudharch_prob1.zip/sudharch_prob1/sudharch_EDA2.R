library(rjson)
JsonData <- fromJSON(file = "/Users/Admin/EDA1/Part1/tweets4.json" )